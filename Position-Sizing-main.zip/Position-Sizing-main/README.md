# Position-Sizing
This app will give you how much capital you should expose with respect to risk.
